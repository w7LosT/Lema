<?php
    //ob_start();
?>

<html>
    <head>
        <meta charset="utf-8">
        <link rel="stylesheet" href="./css/aceitarAula.css">
        <title>Aceitar Aula</title>
    </head>
    <body>
        <div class="wrapper">
            <div class="outer-container">
                <div class="container">
                    <div class="content">
                        <span>Professor</span>
                        <input type="text" name="prof" id="prof" value="<?php //echo $_SESSION['prof']?>">
                    </div>

                    <div class="content">
                        <span>Email do Professor</span>
                        <input type="email" name="emailProf" id="emailProf" value="<?php //echo $_SESSION['email']?>">
                    </div>

                    <div class="content">
                        <span>Disciplina</span>
                        <input type="text" name="nomeDisc" id="nomeDisc" value="<?php //echo $_SESSION['nomeDisc']?>">
                    </div>

                    <div class="content">
                        <span>Curso</span>
                        <input type="text" name="curso" id="curso" value="<?php //echo $_SESSION['curso']?>">
                    </div>
                </div>

                <div class="container">
                    <div class="content">
                        <span>Setor</span>
                        <input type="text" name="setor" id="setor" value="<?php //echo $_SESSION['setor']?>">
                    </div>

                    <div class="content">
                        <span>Data</span>
                        <input type="text" name="data" id="data" value="<?php //echo $_SESSION['data']?>">
                    </div>

                    <div class="content">
                        <span>Hora Início</span>
                        <input type="text" name="horainicio" id="horainicio" value="<?php //echo $_SESSION['horainicio']?>">
                    </div>

                    <div class="content">
                        <span>Hora Final</span>
                        <input type="text" name="horafinal" id="horafinal" value="<?php //echo $_SESSION['horafinal']?>">
                    </div>
                </div>
            </div>
            <div class="botoes">
                <input type="button" value="Aceitar" id="aceitar">
                <input type="button" value="Recusar" id="recusar">
            </div>
        </div>
    </body>
</html>

<?php
    //$html = ob_get_contents();
    //ob_end_clean();
    //file_put_contents($_SESSION['setor'].'-'.$_SESSION['dia'].'-'.$_SESSION['horainicio'].'-'.$_SESSION['horafinal'].".php", $html);

?>